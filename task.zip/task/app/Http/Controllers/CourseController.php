<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;
use DB;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function showallcourse(Request $request)
    {
       $min= $request->post('minimum_price');
       $max=$request->post('maximum_price');
           $data=DB::select("SELECT * FROM courses WHERE courseprice BETWEEN '".$min."' AND '".$max."'");
           if($request->post("topic"))
         {
        $topic_filter = implode("','", $request->post("topic"));
        $data=DB::select("SELECT * FROM courses WHERE courseprice BETWEEN '".$min."' AND '".$max."' AND coursename IN ('".$topic_filter."')");
        
    }
    
    $output='';
    if(!empty($data))
    {
        foreach($data as $row => $val)
        {
            $output .= '
            <div class="col-sm-4 col-lg-12 col-md-3">
                <div style="border:1px solid #ccc; border-radius:5px; padding:16px; margin-bottom:16px; height:450px;">
                    <p align="center"><strong>Course Name: <a href="#">'. $val->coursename.'</a></strong></p>
                    <h4 style="text-align:center;" class="text-danger" >Course Price:'. $val->courseprice.'</h4>

                </div>

            </div>
            ';
        }
    }
    else
    {
        $output = '<h3>No Data Found</h3>';
    }
    echo $output;
    }

   public function sortcourse(Request $request)
   
   {
    $course =Course::get(); 
 
// Define filters 
$conditions = array(); 
 

// If filter request is submitted 
if(!empty($request->post('filter'))){ 
    $sortVal = $request->post('filter'); 
    if($sortVal=='created_at DESC')
    {
        $data=DB::select("SELECT * FROM courses ORDER BY  ".$sortVal."");
    }
    else
    {
        $data=DB::select("SELECT * FROM courses ORDER BY coursename  ".$sortVal."");
    }  
} 

$output='';
    if(!empty($data))
    {
        foreach($data as $row => $val)
        {
            $output .= '
            <div class="col-sm-4 col-lg-12 col-md-3">
                <div style="border:1px solid #ccc; border-radius:5px; padding:16px; margin-bottom:16px; height:450px;">
                    <p align="center"><strong>Course Name: <a href="#">'. $val->coursename.'</a></strong></p>
                    <h4 style="text-align:center;" class="text-danger" >Course Price: '. $val->courseprice.'</h4>

                </div>

            </div>
            ';
        }
    }
    else
    {
        $output = '<h3>No Data Found</h3>';
    }
    echo $output;

}
 
}
