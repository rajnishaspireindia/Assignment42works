<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Course;
use Faker\Factory as Faker;

class CourseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       
        $faker=Faker::create();
         for($i=0;$i<=100;$i++)
        {
        $course=new Course;
        $course->coursename =$faker->title;
        $course->courseprice =$faker->numberBetween($min = 1500, $max = 6000);
        $course->save();
        }

    }
}
